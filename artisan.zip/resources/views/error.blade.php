@extends('layouts.main')

@section('content')
    <section class="home-1">
        <div class="container">
            <div class="row">
               <div class="col-12">
                   <h1 class="text-center">Error 404 - La ruta no existe</h1>
               </div>
            </div>
        </div>
    </section>
@endsection
