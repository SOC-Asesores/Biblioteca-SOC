<?php $__env->startSection('content'); ?>
    <section class="folder-1 <?php echo e($url_folder); ?>">
        <h1 class="<?php echo e($url_folder); ?>">
            <?php echo e($title_folder); ?>

        </h1>
        <?php if(Auth::check()): ?>
            <?php if(Auth::user()->type == 0): ?>
                <div class="container">
                    <div class="row" style="min-height:48px;">
                        <div class="col-12 mb-4 delete-multiple-btn" style="display:none;">
                            <div class="position-relative mr-4 d-inline-block">
                                <a href="#" class="mr-4 clone-multiple"><i class="fa-solid fa-copy"></i> Duplicar seleccionados</a>
                                <form id="duplicate_container">
                                    <small><b>Duplicar a:</b></small>
                                    <select name="duplicate_folder" id="duplicate_folder">
                                        <option value hidden selected>Selecciona una opci&oacute;n</option>
                                        
                                        <?php $__currentLoopData = $folders_main; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($value->id); ?>"><?php echo e($value->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <select name="duplicate_subfolder" id="duplicate_folder_child" class="d-none"></select>
                                    <input type="submit" class="btn btn-success text-sm" value="Duplicar">
                                </form>
                            </div>
                            
                            <div class="position-relative mr-4 d-inline-block">
                                <a href="#" class="mr-4 move-multiple"><i class="fa-solid fa-arrows-up-down-left-right"></i> Mover seleccionados</a>
                                <form id="move_container">
                                    <small><b>Mover a:</b></small>
                                    <select name="move_folder" id="move_folder">
                                        <option value hidden selected>Selecciona una opci&oacute;n</option>
                                        
                                        <?php $__currentLoopData = $folders_main; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($value->id); ?>"><?php echo e($value->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <select name="folder" id="move_folder_child" class="d-none"></select>
                                    <input type="submit" class="btn btn-success text-sm" value="Mover">
                                </form>
                                
                            </div>

                            <a href="" class="mr-4 delete-multiple" data-toggle="modal" data-target="#exampleModalDelete2" style="color: red;"><i class="fa-solid fa-trash-can"></i> Eliminar archivos seleccionados</a>
                            <a href="" id="cancel_selection"><i class="fa fa-times"></i> Cancelar</a>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        <?php endif; ?>
        <div class="container">
            <div class="row">
                
                <?php
                    $counter = 0;
                ?>
                <?php $__currentLoopData = $folders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <span class="position-relative d-inline-block">
                        
                        <a class="tab-link <?php echo e(($counter === 0 ? 'active' : '').' '.(Auth::check() ? 'pr-5' : '')); ?>" onclick="api1.setNextPanel(<?php echo e($counter); ?>);api1.updateClass($(this))"><?php echo e($value->name); ?></a>
                        <?php if(Auth::check() && Auth::user()->type == 0): ?>
                            <span class="more-link more-link-floating" data-id="<?php echo e($value->id); ?>"></span>
                            <div class="menu-more-items small-more-items d-none" id="more_<?php echo e($value->id); ?>">
                                <button class="delete_folder text-center link_folder_<?php echo e($value->id); ?>" id="<?php echo e($value->id); ?>" href="">Borrar carpeta</button>
                            </div>
                        <?php endif; ?>
                    </span>
                    <?php
                        $counter++;
                    ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="row">
                <div class="col-12">
                <div class="liquid-slider" id="slider">
                    <?php $__currentLoopData = $folders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div>
                        <div class="container">
                            
                            <div class="mt-4 row align-items-start">
                                <?php $__currentLoopData = $sub_folders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $sub_folder_main): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php $__currentLoopData = $sub_folder_main; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $sub_folder): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                         <?php if($value->id === $sub_folder->id_folder): ?>
                                            <div class="col-md-2" id="sub_folder<?php echo e($sub_folder->id); ?>">
                                                <?php if(Auth::check()): ?>   
                                                        <?php if(Auth::user()->type == 0): ?>
                                                            <label class="floating-checkbox">
                                                                <input type="checkbox" class="form-check-input folder_multiple" data-id="<?php echo e($sub_folder->id); ?>" name="select_folder[]">
                                                            </label>
                                                        <?php endif; ?>
                                                    <?php endif; ?>
                                                <a href="<?php echo e(url('/')); ?>/folder/<?php echo e($sub_folder->url); ?>" id="folder_<?php echo e($sub_folder->id); ?>">
                                                    <div class="content text-center" style="box-shadow: 0px 3px 6px #00000029; border-radius: 5px; padding: 10px">
                                                        <img src="<?php echo e(url('img')); ?>/<?php echo e($sub_folder->img); ?>" class="img-fluid" alt="">
                                                        <?php if($sub_folder->hide == 0): ?>
                                                            
                                                            <div class="position-relative">
                                                                <p class="menu-more" id="menu-more-<?php echo e($sub_folder->id); ?>">
                                                                    <span><?php echo e($sub_folder->name); ?></span>
                                                                </p>
                                                                <input type="text" class="more-name form-control d-none" id="more-name-<?php echo e($sub_folder->id); ?>" data-id="<?php echo e($sub_folder->id); ?>" data-type="folder" value="<?php echo e($sub_folder->name); ?>">
                                                            </div>
                                                        <?php endif; ?>
                                                        
                                                    </div>
                                                </a>
                                                <?php if(Auth::check() && Auth::user()->type == 0): ?>
                                                <span class="more-link more-link-floating" data-id="<?php echo e($sub_folder->id); ?>"></span>
                                                    <div class="menu-more-items small-more-items d-none" id="more_<?php echo e($sub_folder->id); ?>">
                                                        <a href="" class="more_name_link d-block" data-type="folder" data-id="<?php echo e($sub_folder->id); ?>">Cambiar nombre</a>
                                                        <a href="" class="select_link" data-id="<?php echo e($sub_folder->id); ?>">Seleccionar</a>
                                                        <a class="delete delete_folder link_folder_<?php echo e($sub_folder->id); ?>" id="<?php echo e($sub_folder->id); ?>" href="">Eliminar</a>
                                                    </div>
                                                <?php else: ?>
                                                <?php endif; ?>
                                            </div>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <div class="row align-items-start">
                                <?php $__currentLoopData = $archives; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $archives_main): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php $__currentLoopData = $archives_main; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $archives_file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if(isset($archives_file->id_folder)): ?>
                                            <?php if($value->id === $archives_file->id_folder): ?>
                                                <div class="col-md-2" id="content_files_<?php echo e($archives_file->id); ?>">
                                                    <?php if(Auth::check()): ?>   
                                                        <?php if(Auth::user()->type == 0): ?>
                                                            <label class="floating-checkbox">
                                                                <input type="checkbox" class="form-check-input archivos_multiple" data-id="<?php echo e($archives_file->id); ?>" name="select[]">
                                                            </label>
                                                        <?php endif; ?>
                                                    <?php endif; ?>
                                                    <a href="<?php echo e(url('img')); ?>/archivos/<?php echo e($archives_file->img); ?>" id="files_<?php echo e($archives_file->id); ?>" target="_blank">
                                                        <div class="content text-center">
                                                            <?php
                                                                $icon = "icon";
                                                                $imagen = explode(".", $archives_file->img);
                                                                if (end($imagen) == "jpg" || end($imagen) == "png" || end($imagen) == "jpeg") {
                                                                    $registro_imagen = "archivos/".$archives_file->img;
                                                                    $icon = "";
                                                                }else if ($imagen[1] == "pdf") {
                                                                    $registro_imagen = "/icons/pdf.png";
                                                                }else if ($imagen[1] == "3ds") {
                                                                    $registro_imagen = "/icons/3ds.png";
                                                                }else if ($imagen[1] == "aac") {
                                                                    $registro_imagen = "/icons/aac.png";
                                                                }else if ($imagen[1] == "ai") {
                                                                    $registro_imagen = "/icons/ai.png";
                                                                }else if ($imagen[1] == "avi") {
                                                                    $registro_imagen = "/icons/avi.png";
                                                                }else if ($imagen[1] == "bmp") {
                                                                    $registro_imagen = "/icons/bmp.png";
                                                                }else if ($imagen[1] == "cad") {
                                                                    $registro_imagen = "/icons/cad.png";
                                                                }else if ($imagen[1] == "cdr") {
                                                                    $registro_imagen = "/icons/cdr.png";
                                                                }else if ($imagen[1] == "css") {
                                                                    $registro_imagen = "/icons/css.png";
                                                                }else if ($imagen[1] == "dat") {
                                                                    $registro_imagen = "/icons/dat.png";
                                                                }else if ($imagen[1] == "dll") {
                                                                    $registro_imagen = "/icons/dll.png";
                                                                }else if ($imagen[1] == "dmg") {
                                                                    $registro_imagen = "/icons/dmg.png";
                                                                }else if ($imagen[1] == "doc") {
                                                                    $registro_imagen = "/icons/doc.png";
                                                                }else if ($imagen[1] == "eps") {
                                                                    $registro_imagen = "/icons/eps.png";
                                                                }else if ($imagen[1] == "fla") {
                                                                    $registro_imagen = "/icons/fla.png";
                                                                }else if ($imagen[1] == "flv") {
                                                                    $registro_imagen = "/icons/flv.png";
                                                                }else if ($imagen[1] == "gif") {
                                                                    $registro_imagen = "/icons/gif.png";
                                                                }else if ($imagen[1] == "jpeg") {
                                                                    $registro_imagen = "/icons/jpg.png";
                                                                }else if ($imagen[1] == "html") {
                                                                    $registro_imagen = "/icons/html.png";
                                                                }else if ($imagen[1] == "indd") {
                                                                    $registro_imagen = "/icons/indd.png";
                                                                }else if ($imagen[1] == "iso") {
                                                                    $registro_imagen = "/icons/iso.png";
                                                                }else if ($imagen[1] == "js") {
                                                                    $registro_imagen = "/icons/js.png";
                                                                }else if ($imagen[1] == "midi") {
                                                                    $registro_imagen = "/icons/midi.png";
                                                                }else if ($imagen[1] == "mov") {
                                                                    $registro_imagen = "/icons/mov.png";
                                                                }else if ($imagen[1] == "mp3") {
                                                                    $registro_imagen = "/icons/mp3.png";
                                                                }else if ($imagen[1] == "mpg") {
                                                                    $registro_imagen = "/icons/mpg.png";
                                                                }else if ($imagen[1] == "php") {
                                                                    $registro_imagen = "/icons/php.png";
                                                                }else if ($imagen[1] == "ppt") {
                                                                    $registro_imagen = "/icons/ppt.png";
                                                                }else if ($imagen[1] == "pptx") {
                                                                    $registro_imagen = "/icons/ppt.png";
                                                                }else if ($imagen[1] == "pptx") {
                                                                    $registro_imagen = "/icons/ppt.png";
                                                                }else if ($imagen[1] == "ps") {
                                                                    $registro_imagen = "/icons/ps.png";
                                                                }else if ($imagen[1] == "psd") {
                                                                    $registro_imagen = "/icons/psd.png";
                                                                }else if ($imagen[1] == "raw") {
                                                                    $registro_imagen = "/icons/raw.png";
                                                                }else if ($imagen[1] == "sql") {
                                                                    $registro_imagen = "/icons/sql.png";
                                                                }else if ($imagen[1] == "svg") {
                                                                    $registro_imagen = "/icons/svg.png";
                                                                }else if ($imagen[1] == "tif") {
                                                                    $registro_imagen = "/icons/tif.png";
                                                                }else if ($imagen[1] == "txt") {
                                                                    $registro_imagen = "/icons/txt.png";
                                                                }else if ($imagen[1] == "wmv") {
                                                                    $registro_imagen = "/icons/wmv.png";
                                                                }else if ($imagen[1] == "xls") {
                                                                    $registro_imagen = "/icons/xls.png";
                                                                }else if ($imagen[1] == "xlsx") {
                                                                    $registro_imagen = "/icons/xls.png";
                                                                }else if ($imagen[1] == "xml") {
                                                                    $registro_imagen = "/icons/xml.png";
                                                                }else if ($imagen[1] == "zip") {
                                                                    $registro_imagen = "/icons/zip.png";
                                                                }else if ($imagen[1] == "mp4") {
                                                                    $registro_imagen = "/icons/mp4.png";
                                                                }else{
                                                                    $registro_imagen = "document.png";
                                                                }
                                                            ?>
                                                            <img src="<?php echo e(url('img')); ?>/<?php echo e($registro_imagen); ?>" class="img-fluid <?php echo e($icon); ?>" alt="">
                                                            <?php if($archives_file->hide == 0): ?>
                                                                <?php
                                                                    
                                                                    $cadena = substr($archives_file->img, 0, 30);
                                                                ?>
                                                                 

                                                                <div class="position-relative">
                                                                    <p class="menu-more" id="menu-more-<?php echo e($archives_file->id); ?>">
                                                                        <span><?php echo e($cadena); ?></span>
                                                                    </p>
                                                                    <input type="text" class="more-name form-control d-none" id="more-name-<?php echo e($archives_file->id); ?>" data-id="<?php echo e($archives_file->id); ?>" data-type="file" value="<?php echo e($archives_file->img); ?>">
                                                                </div>
                                                            <?php else: ?>
                                                            <?php endif; ?>
                                                        </div>
                                                    </a>
                                                    <?php if(Auth::check() && Auth::user()->type == 0): ?>
                                                        <span class="more-link more-link-floating" data-id="<?php echo e($archives_file->id); ?>"></span>
                                                        <div class="menu-more-items small-more-items d-none" id="more_<?php echo e($archives_file->id); ?>">
                                                            <a href="" class="more_name_link d-block" data-type="file" data-id="<?php echo e($archives_file->id); ?>">Cambiar nombre</a>
                                                            <a href="" class="select_link" data-id="<?php echo e($archives_file->id); ?>">Seleccionar</a>
                                                            <a class="delete delete_file link_files_<?php echo e($archives_file->id); ?>" id="<?php echo e($archives_file->id); ?>" href="">Eliminar</a>
                                                        </div>            
                                                    <?php else: ?>
                                                    <?php endif; ?>
                                                </div>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </section>
    <style>.more-name{padding-right:1.65em}.more-name-btn-submit{right:0;bottom:.65em;}.panel-wrapper{padding: 15px 15px 110px 15px !important;}</style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp74\htdocs\biblioteca.socasesores.com\resources\views/folder.blade.php ENDPATH**/ ?>