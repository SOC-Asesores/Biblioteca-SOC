<?php $__env->startSection('content'); ?>
    <section class="home-1">
        <div class="container">
            <?php if(Auth::check()): ?>
                <?php if(Auth::user()->type == 0): ?>
            <div class="container">
                <div class="row justify-content-between" style="min-height:48px;">
                    <div class="col-md-5 mb-4">
                        <div class="delete-multiple-btn" style="display:none;">
                            <a href="" class="mr-4 delete-multiple" data-toggle="modal" data-target="#exampleModalDelete2" style="color: red;"><i class="fa-solid fa-trash-can"></i> Eliminar archivos seleccionados</a>
                            <a href="" id="cancel_selection"><i class="fa fa-times"></i> Cancelar</a>
                        </div>
                    </div>
                    
                </div>
            </div>
                <?php endif; ?>
            <?php endif; ?>

            <div class="row align-items-end">
                <?php
                    $total_items = @count($folders_main);
                    $items_last_row = $total_items % 4 > 0 ? ($total_items % 4) : 4;
                ?>
                <?php $__currentLoopData = $folders_main; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-3 position-relative" id="home_folder<?php echo e($value->id); ?>">
                        <div class="position-relative">
                            <?php if(Auth::check()): ?>   
                                <?php if(Auth::user()->type == 0): ?>
                                <label class="floating-checkbox">
                                    <input type="checkbox" class="form-check-input folder_multiple" data-id="<?php echo e($value->id); ?>" name="select_folder[]">
                                </label>
                                <?php endif; ?>
                            <?php endif; ?>
                            <a href="<?php echo e(url('/')); ?>/<?php echo e($value->url); ?>">
                                <div class="content">
                                    <div class="img-back" style="background-image: url(<?php echo e(url('/')); ?>/img/<?php echo e($value->img); ?>)"></div>
                                </div>
                            </a>
                        </div>
                        <div class="position-relative">
                            <p class="title menu-more" id="menu-more-<?php echo e($value->id); ?>">
                                <span><?php echo e($value->name); ?></span>
                                <?php if(Auth::check()): ?>
                                    <?php if(Auth::user()->type == 0): ?>
                                        <a href="" class="more-link" data-id="<?php echo e($value->id); ?>">
                                            <img src="<?php echo e(url('img/more.png')); ?>" alt="" class="img-fluid">
                                        </a>
                                    <?php endif; ?>
                                <?php endif; ?>
                                </p>
                            <input type="text" class="more-name form-control d-none" id="more-name-<?php echo e($value->id); ?>" data-id="<?php echo e($value->id); ?>" data-type="folder" value="<?php echo e($value->name); ?>">
                            <div class="menu-more-items <?php echo e($key >= (count($folders_main) - $items_last_row)  ? 'last-row-4' : ''); ?> d-none" id="more_<?php echo e($value->id); ?>">
                                <a href="" class="more_name_link d-block" data-type="folder" data-id="<?php echo e($value->id); ?>">Cambiar nombre</a>
                                <a href="" class="select_link" data-id="<?php echo e($value->id); ?>">Selecionar</a>
                                <a class="delete delete_folder d-block link_folder_<?php echo e($value->id); ?>" id="<?php echo e($value->id); ?>" href="">Eliminar</a>    
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp74\htdocs\biblioteca.socasesores.com\resources\views/user.blade.php ENDPATH**/ ?>