

<?php $__env->startSection('content'); ?>
    <section class="home-1">
        <div class="container">
            <div class="row">
                <?php $__currentLoopData = $folders_main; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-3">
                        <a href="<?php echo e(url('/')); ?>/<?php echo e($value->url); ?>">
                            <div class="content">
                                <div class="img-back" style="background-image: url(<?php echo e(url('/')); ?>/img/<?php echo e($value->img); ?>)"></div>
                                <p class="title"><?php echo e($value->name); ?></p>
                            </div>
                        </a>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp74\htdocs\bibliotecaSoc\resources\views/home.blade.php ENDPATH**/ ?>